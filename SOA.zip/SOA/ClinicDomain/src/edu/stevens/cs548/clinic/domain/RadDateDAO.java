package edu.stevens.cs548.clinic.domain;

import javax.persistence.EntityManager;

public class RadDateDAO implements IRadDateDAO {

	private EntityManager em;
	
	public RadDateDAO (EntityManager em) {
		this.em = em;
	}
	
	@Override
	public void addRadDate(RadDate date) {
		em.persist(date);
	}

}
