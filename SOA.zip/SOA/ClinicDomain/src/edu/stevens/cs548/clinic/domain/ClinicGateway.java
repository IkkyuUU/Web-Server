package edu.stevens.cs548.clinic.domain;

import javax.persistence.EntityManager;

public class ClinicGateway implements IClinicGateway {

	@Override
	public IPatientFactory getPatientFactory() {
		return new PatientFactory();
	}

	//private EntityManagerFactory emf;
	
	private EntityManager em;
	
	@Override
	public IPatientDAO getPatientDAO() {
		//EntityManager em = emf.createEntityManager();
		return new PatientDAO(em);
	}

	public ClinicGateway(EntityManager em) {
		//emf = Persistence.createEntityManagerFactory("ClinicDomain");
		this.em = em;
	}

	@Override
	public IProviderFactory getProviderFactory() {
		return new ProviderFactory();
	}

	@Override
	public IProviderDAO getProviderDAO() {
		//EntityManager em = emf.createEntityManager();
		return new ProviderDAO(em);
	}

	@Override
	public ITreatmentFactory getTreatmentFactory() {
		return new TreatmentFactory();
	}

	@Override
	public IRadDateDAO getRadDateDAO() {
		return new RadDateDAO(em);
	}

	@Override
	public IRadDateFactory getRadDateFactory() {
		return new RadDateFactory();
	}
	
}
