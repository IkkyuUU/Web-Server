package edu.stevens.cs548.clinic.domain;

import java.util.Date;
import javax.annotation.Generated;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value="Dali", date="2015-10-04T00:01:55.432-0400")
@StaticMetamodel(RadDate.class)
public class RadDate_ {
	public static volatile SingularAttribute<RadDate, Long> id;
	public static volatile SingularAttribute<RadDate, Date> date;
	public static volatile SingularAttribute<RadDate, Radiology> radiology;
}
