package edu.stevens.cs548.clinic.domain;

public interface IRadDateDAO {

	public static class RadDateExn extends Exception {
		private static final long serialVersionUID = 1L;
		public RadDateExn (String msg) {
			super(msg);
		}
	}
	
	public void addRadDate (RadDate date);
	
}
