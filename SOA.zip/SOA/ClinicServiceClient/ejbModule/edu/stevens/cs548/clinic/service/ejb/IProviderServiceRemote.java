package edu.stevens.cs548.clinic.service.ejb;

public interface IProviderServiceRemote {

}
