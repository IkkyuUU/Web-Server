package edu.stevens.cs548.clinic.service.dto.util;

import java.util.Date;
import java.util.List;

import edu.stevens.cs548.clinic.domain.RadDate;
import edu.stevens.cs548.clinic.service.dto.DrugTreatmentType;
import edu.stevens.cs548.clinic.service.dto.ObjectFactory;
import edu.stevens.cs548.clinic.service.dto.PatientDto;
import edu.stevens.cs548.clinic.service.dto.ProviderDto;
import edu.stevens.cs548.clinic.service.dto.RadDateType;
import edu.stevens.cs548.clinic.service.dto.RadiologyType;
import edu.stevens.cs548.clinic.service.dto.SurgeryType;
import edu.stevens.cs548.clinic.service.dto.TreatmentDto;

public class TreatmentDtoFactory {
	
	ObjectFactory factory;
	
	public TreatmentDtoFactory() {
		factory = new ObjectFactory();
	}
	
	public TreatmentDto createTreatmentDto (
			String diagnosis, String drug, float dosage, 
			PatientDto patientDto, ProviderDto providerDto) {
		TreatmentDto dto = factory.createTreatmentDto();
		
		DrugTreatmentType drugInfo = factory.createDrugTreatmentType();
		drugInfo.setName(drug);
		drugInfo.setDosage(dosage);
		
		dto.setDiagnosis(diagnosis);
		dto.setPatient(patientDto.getId());
		dto.setProvider(providerDto.getId());
		dto.setDrugTreatment(drugInfo);
		return dto;
	}
	
	public TreatmentDto createTreatmentDto (
			String diagnosis, Date date, 
			PatientDto patientDto, ProviderDto providerDto) {
		TreatmentDto dto = factory.createTreatmentDto();
		SurgeryType surInfo = factory.createSurgeryType();
		surInfo.setDate(date);
		dto.setDiagnosis(diagnosis);
		dto.setPatient(patientDto.getId());
		dto.setProvider(providerDto.getId());
		dto.setSurgery(surInfo);
		return dto;
	}

	public TreatmentDto createTreatmentDto (
			String diagnosis, List<RadDate> dates,
			PatientDto patientDto, ProviderDto providerDto) {
		TreatmentDto dto = factory.createTreatmentDto();
		dto.setDiagnosis(diagnosis);
		dto.setPatient(patientDto.getId());
		dto.setProvider(providerDto.getId());
		RadiologyType radInfo = factory.createRadiologyType();
		RadDateType rdInfo;
		for (int i=0; i< dates.size(); i++){	
			rdInfo = factory.createRadDateType();
			rdInfo.setDate(dates.get(i).getDate());
			radInfo.getDate().add(rdInfo);
		}
		dto.setRadiology(radInfo);
		return dto;
	}
}
