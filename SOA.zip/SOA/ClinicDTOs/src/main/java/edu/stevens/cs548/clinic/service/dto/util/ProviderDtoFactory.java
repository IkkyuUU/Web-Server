package edu.stevens.cs548.clinic.service.dto.util;

import edu.stevens.cs548.clinic.domain.Provider;
import edu.stevens.cs548.clinic.service.dto.ProviderDto;
import edu.stevens.cs548.clinic.service.dto.SpecializationType;
import edu.stevens.cs548.clinic.service.dto.ObjectFactory;

public class ProviderDtoFactory {
	
	ObjectFactory factory;
	
	public ProviderDtoFactory() {
		factory = new ObjectFactory();
	}
	
	public ProviderDto createProviderDto () {
		return factory.createProviderDto();
	}
	
	public ProviderDto createProviderDto (Provider p) {
		ProviderDto d = factory.createProviderDto();
		/*
		 * Initialize the fields of the DTO.
		 */
		d.setId(p.getId());
		d.setName(p.getName());
		d.setProviderId(p.getNpi());
		d.setSpecialization(edu.stevens.cs548.clinic.service.dto.SpecializationType.valueOf(p.getSpecialization().getTag()));
		return d;
	}
	
	public ProviderDto createProviderDto (long npi, String name, SpecializationType spec) {
		ProviderDto d = factory.createProviderDto();
		/*
		 * Initialize the fields of the DTO.
		 */
		d.setName(name);
		d.setProviderId(npi);
		d.setSpecialization(spec);
		return d;
	}
}