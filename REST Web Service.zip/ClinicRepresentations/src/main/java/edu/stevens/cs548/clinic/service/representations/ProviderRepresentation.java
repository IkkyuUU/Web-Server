package edu.stevens.cs548.clinic.service.representations;

import java.util.List;

import javax.ws.rs.core.UriBuilder;
import javax.ws.rs.core.UriInfo;

import edu.stevens.cs548.clinic.service.dto.ProviderDto;
import edu.stevens.cs548.clinic.service.dto.util.ProviderDtoFactory;
import edu.stevens.cs548.clinic.service.web.rest.data.ProviderType;
import edu.stevens.cs548.clinic.service.web.rest.data.SpecializationType;
import edu.stevens.cs548.clinic.service.web.rest.data.dap.LinkType;

public class ProviderRepresentation extends ProviderType {

	public List<LinkType> getLinksTreatments() {
		return this.getTreatments();
	}
	
	private ProviderDtoFactory providerDtoFactory;
	
	public static LinkType getProviderLink(long id, UriInfo uriInfo) {
		UriBuilder ub = uriInfo.getBaseUriBuilder();
		ub.path("provider").path("{id}");
		String providerURI = ub.build(Long.toString(id)).toString();

		LinkType link = new LinkType();
		link.setUrl(providerURI);
		link.setRelation(Representation.RELATION_PATIENT);
		link.setMediaType(Representation.MEDIA_TYPE);
		return link;
	}
	
	public ProviderRepresentation () {
		super();
		this.providerDtoFactory = new ProviderDtoFactory();
	}
	
	public ProviderRepresentation (ProviderDto providerDto, UriInfo uriInfo) {
		this();
		this.id = getProviderLink(providerDto.getId(), uriInfo);
		this.npi = providerDto.getProviderId();
		this.name = providerDto.getName();
		this.specialization = SpecializationType.valueOf(providerDto.getSpecialization().value().toUpperCase());
		/*
		 * Call getTreatments to initialize empty list.
		 */
		List<LinkType> links = this.getTreatments();
		for (long t : providerDto.getTreatments()) {
			links.add(TreatmentRepresentation.getTreatmentLink(t, uriInfo));
		}
	}
	
	public ProviderDto getProviderDto() {
		ProviderDto p = providerDtoFactory.createProviderDto();
		p.setId(Representation.getId(this.id));
		p.setProviderId(this.getNpi());
		p.setName(this.name);
		p.setSpecialization(edu.stevens.cs548.clinic.service.dto.SpecializationType.valueOf(this.getSpecialization().value().toUpperCase()));
		return p;
	}
	
}
