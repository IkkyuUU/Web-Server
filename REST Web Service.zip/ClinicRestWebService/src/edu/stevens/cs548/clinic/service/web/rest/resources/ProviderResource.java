package edu.stevens.cs548.clinic.service.web.rest.resources;

import java.net.URI;

import javax.enterprise.context.RequestScoped;
import javax.inject.Inject;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.WebApplicationException;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.UriBuilder;
import javax.ws.rs.core.UriInfo;

import edu.stevens.cs548.clinic.service.dto.ProviderDto;
import edu.stevens.cs548.clinic.service.dto.TreatmentDto;
import edu.stevens.cs548.clinic.service.dto.util.ProviderDtoFactory;
import edu.stevens.cs548.clinic.service.ejb.IPatientService.PatientNotFoundExn;
import edu.stevens.cs548.clinic.service.ejb.IProviderService.ProviderServiceExn;
import edu.stevens.cs548.clinic.service.ejb.IProviderServiceLocal;
import edu.stevens.cs548.clinic.service.representations.ProviderRepresentation;
import edu.stevens.cs548.clinic.service.representations.TreatmentRepresentation;

@Path("/provider")
@RequestScoped
public class ProviderResource {

	@Context
    private UriInfo uriInfo;

    @Inject
    private IProviderServiceLocal providerService;
    
    private ProviderDtoFactory providerDtoFactory;
    
    /**
     * Default constructor. 
     */
    public ProviderResource() {
    	this.providerDtoFactory = new ProviderDtoFactory();
    }
    
    @GET
    @Path("site")
    @Produces("text/plain")
    public String getSiteInfo() {
    	return providerService.siteInfo();
    }
    
    
    @POST
	@Consumes("application/xml")
    public Response addProvider(ProviderRepresentation providerRep) {
    	try {
    		ProviderDto dto = providerDtoFactory.createProviderDto();
    		dto.setProviderId(providerRep.getNpi());
    		dto.setName(providerRep.getName());
    		dto.setSpecialization(edu.stevens.cs548.clinic.service.dto.SpecializationType.valueOf(providerRep.getSpecialization().value().toUpperCase()));
    		long id = providerService.addProvider(dto);
    		UriBuilder ub = uriInfo.getAbsolutePathBuilder().path("{id}");
    		URI url = ub.build(Long.toString(id));
    		return Response.created(url).build();
    	} catch (ProviderServiceExn e) {
    		throw new WebApplicationException();
    	}
    }


    /**
     * Retrieves representation of an instance of ProviderResource
     */
    @GET
    @Path("{id}")
    @Produces("application/xml")
    public ProviderRepresentation getProvider(@PathParam("id") String id) {
    	
    	try{
    		long key = Long.parseLong(id);
    		ProviderDto providerDto = providerService.getProvider(key);
    		ProviderRepresentation providerRepresentation = new ProviderRepresentation(providerDto, uriInfo);
    		return providerRepresentation;
    	} catch (ProviderServiceExn e){
    		throw new WebApplicationException(Response.Status.NOT_FOUND);
    	}
    }
    
    @GET
    @Path("npi")
    public ProviderRepresentation getProviderByNPI(@QueryParam("id") String npi) {
    	
    	try{
    		long Npi = Long.parseLong(npi);
    		ProviderDto providerDto = providerService.getProvider(Npi);
    		ProviderRepresentation providerRepresentation = new ProviderRepresentation(providerDto, uriInfo);
    		return providerRepresentation;
    	} catch (ProviderServiceExn e){
    		throw new WebApplicationException(Response.Status.NOT_FOUND);
    	}    	
    }
    
    @POST
    @Path("tid")
	@Consumes("application/xml")
    public Response addTreatmentForPat(TreatmentRepresentation treatmentRep){
		try {
	    	TreatmentDto tdto = treatmentRep.getTreatment();
			long tid = providerService.addTreatment(tdto);
			UriBuilder ub = uriInfo.getAbsolutePathBuilder().path("{id}").path("treatments");
			URI url = ub.build(Long.toString(tid));
			return Response.created(url).build();
		} catch (PatientNotFoundExn | ProviderServiceExn e) {
			throw new WebApplicationException(Response.Status.NOT_FOUND);
		}
    }


}