package edu.stevens.cs548.clinic.domain;

import java.util.Date;

public class RadDateFactory implements IRadDateFactory {

	@Override
	public RadDate createRadDate(Date date) {
		return new RadDate();
	}

}
