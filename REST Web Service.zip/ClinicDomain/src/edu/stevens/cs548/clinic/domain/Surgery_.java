package edu.stevens.cs548.clinic.domain;

import java.util.Date;
import javax.annotation.Generated;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value="Dali", date="2015-10-04T00:04:47.071-0400")
@StaticMetamodel(Surgery.class)
public class Surgery_ extends Treatment_ {
	public static volatile SingularAttribute<Surgery, String> type;
	public static volatile SingularAttribute<Surgery, Date> date;
}
