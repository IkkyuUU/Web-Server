package edu.stevens.cs548.clinic.domain;

public class ProviderFactory implements IProviderFactory {

	@Override
	public Provider createProvider(long npi, String name, SpecializationType specializationType) {
		
		Provider provider = new Provider();
		provider.setNpi(npi);
		provider.setName(name);
		provider.setSpecialization(specializationType);
		return provider;
	}

}
