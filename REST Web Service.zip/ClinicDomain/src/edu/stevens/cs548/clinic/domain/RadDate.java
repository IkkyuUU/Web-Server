package edu.stevens.cs548.clinic.domain;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.*;

/**
 * Entity implementation class for Entity: RadDate
 *
 */
@Entity
@Table(name = "RADDATE")
public class RadDate implements Serializable {

	
	private static final long serialVersionUID = 1L;
	
	@Id
	@GeneratedValue
	private long id;
	
	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}
	
	@Temporal(TemporalType.DATE)
	private Date date;
	
	public void setDate(Date date) {
		this.date = date;
	}
	
	public Date getDate() {
		return date;
	}
	
	@ManyToOne
	@JoinColumn(name = "radiology_fk")
	private Radiology radiology;
	
	public void setRadiology(Radiology radiology) {
		this.radiology = radiology;
		if (!radiology.getDates().contains(this))
			radiology.addRadDate(this);	}
	
	public Radiology getRadiology() {
		return radiology;
	}

	public RadDate() {
		super();
	}
   
}
