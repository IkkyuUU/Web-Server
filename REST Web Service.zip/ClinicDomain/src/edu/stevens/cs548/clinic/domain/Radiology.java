package edu.stevens.cs548.clinic.domain;

import edu.stevens.cs548.clinic.domain.Treatment;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import javax.persistence.*;

/**
 * Entity implementation class for Entity: Radiology
 *
 */
@Entity
@DiscriminatorValue("RA")

public class Radiology extends Treatment implements Serializable {

	
	private static final long serialVersionUID = 1L;
	
	private String type;
	@OneToMany(cascade = { CascadeType.REMOVE, CascadeType.PERSIST }, mappedBy = "radiology")
	private List<RadDate> dates;
	
	public void setType(String type) {
		this.type = type;
	}
	
	public String getType() {
		return type;
	}
	
	public void setDates(List<RadDate> dates) {
		this.dates = dates;
	}
	
	public List<RadDate> getDates() {
		return dates;
	}
	
	public <T> T export(ITreatmentExporter<T> visitor) {
		return visitor.exportRadiology( this.getId(), 
								   		this.getDiagnosis(),
								   		this.dates);
	}
	
	@Transient
	private IRadDateDAO radDateDAO;
	
	public void setRadDateDAO (IRadDateDAO rdao){
		this.radDateDAO = rdao;
	}
	
	public void addRadDate (RadDate rd) {
		this.radDateDAO.addRadDate(rd);
		if (rd.getRadiology() != this) {
			rd.setRadiology(this);
		}
	}

	public Radiology() {
		super();
		this.setTreatmentType(TreatmentType.RADIOLOGY.getTag());
		dates = new ArrayList<RadDate>();
	}
   
}
