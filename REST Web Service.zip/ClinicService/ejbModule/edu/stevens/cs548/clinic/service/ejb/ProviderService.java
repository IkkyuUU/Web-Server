package edu.stevens.cs548.clinic.service.ejb;

import java.util.ArrayList;
import java.util.List;
import java.util.logging.Logger;

import javax.annotation.PostConstruct;
import javax.annotation.Resource;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import edu.stevens.cs548.clinic.domain.IPatientDAO;
import edu.stevens.cs548.clinic.domain.IPatientDAO.PatientExn;
import edu.stevens.cs548.clinic.domain.IProviderDAO;
import edu.stevens.cs548.clinic.domain.IProviderDAO.ProviderExn;
import edu.stevens.cs548.clinic.domain.IProviderFactory;
import edu.stevens.cs548.clinic.domain.IRadDateDAO;
import edu.stevens.cs548.clinic.domain.IRadDateFactory;
import edu.stevens.cs548.clinic.domain.ITreatmentFactory;
import edu.stevens.cs548.clinic.domain.Patient;
import edu.stevens.cs548.clinic.domain.PatientDAO;
import edu.stevens.cs548.clinic.domain.Provider;
import edu.stevens.cs548.clinic.domain.ProviderDAO;
import edu.stevens.cs548.clinic.domain.ProviderFactory;
import edu.stevens.cs548.clinic.domain.RadDate;
import edu.stevens.cs548.clinic.domain.RadDateDAO;
import edu.stevens.cs548.clinic.domain.RadDateFactory;
import edu.stevens.cs548.clinic.domain.SpecializationType;
import edu.stevens.cs548.clinic.domain.Treatment;
import edu.stevens.cs548.clinic.domain.TreatmentFactory;
import edu.stevens.cs548.clinic.service.dto.ObjectFactory;
import edu.stevens.cs548.clinic.service.dto.ProviderDto;
import edu.stevens.cs548.clinic.service.dto.RadDateType;
import edu.stevens.cs548.clinic.service.dto.TreatmentDto;
import edu.stevens.cs548.clinic.service.ejb.IPatientService.PatientNotFoundExn;

@Stateless(name="ProviderServiceBean")
public class ProviderService implements IProviderServiceLocal, 
		IProviderServiceRemote {
	
	@SuppressWarnings("unused")
	private Logger logger = Logger.getLogger(ProviderService.class.getCanonicalName());

	private IProviderFactory providerFactory;
	
	private ITreatmentFactory treatmentFactory;
	
	private IRadDateFactory radDateFactory;
	
	private IProviderDAO providerDAO;
	
	private IPatientDAO patientDAO;
	
	private IRadDateDAO radDateDAO;
	
	public ProviderService() {
		providerFactory = new ProviderFactory();
		treatmentFactory = new TreatmentFactory();
		radDateFactory = new RadDateFactory();
	}
	
	@PersistenceContext(unitName = "ClinicDomain")
	private EntityManager em;
	
	@PostConstruct
	private void initialize() {
		providerDAO = new ProviderDAO(em);
		patientDAO = new PatientDAO(em);
		radDateDAO = new RadDateDAO(em);
	}
	

	@Override
	public long addProvider(ProviderDto dto) throws ProviderServiceExn {
		try {
			Provider provider = providerFactory.createProvider(dto.getProviderId(), dto.getName(), SpecializationType.valueOf(dto.getSpecialization().value().toUpperCase()));
			providerDAO.addProvider(provider);
			return provider.getId();
		} catch (ProviderExn e) {
			throw new ProviderServiceExn(e.toString());
		}
	}
	
	private ProviderDto ProviderPDOtoDTO (Provider provider) {
		
		ObjectFactory factory = new ObjectFactory();
		ProviderDto dto = factory.createProviderDto();
		
		dto.setId(provider.getId());
		dto.setProviderId(provider.getNpi());
		dto.setName(provider.getName());
		dto.setSpecialization(edu.stevens.cs548.clinic.service.dto.SpecializationType.valueOf(provider.getSpecialization().getTag().toUpperCase()));
		List<Long> tids = provider.getTreatmentIds();
		for (int i = 0; i < tids.size(); i++ ) {
			dto.getTreatments().add(tids.get(i));
		}
		
		return dto;
		
	}

	@Override
	public ProviderDto getProvider(long id) throws ProviderServiceExn {
		
		try {
			Provider provider = providerDAO.getProvider(id);
			return ProviderPDOtoDTO(provider);
		} catch (ProviderExn e) {
			throw new ProviderServiceExn(e.toString());
		}
	}

	@Override
	public ProviderDto getProviderByNpi(long npi) throws ProviderServiceExn {

		try {
			Provider provider = providerDAO.getProviderByNPI(npi);
			return ProviderPDOtoDTO(provider);
		} catch (ProviderExn e) {
			throw new ProviderServiceExn(e.toString());
		}
	}

	@Override
	public void deleteProvider() throws ProviderServiceExn {
		
		try {
			providerDAO.deleteProvider();
		} catch (ProviderExn e) {
			throw new ProviderServiceExn(e.toString());
		}
	}

	@Override
	public long addTreatment(TreatmentDto treatmentDto) throws ProviderNotFoundExn, PatientNotFoundExn {

		try {
			Provider provider = providerDAO.getProvider(treatmentDto.getProvider());
			Patient patient = patientDAO.getPatient(treatmentDto.getPatient());
			Treatment treatment;
			if (treatmentDto.getDrugTreatment() != null) {
				treatment = treatmentFactory.createDrugTreatment(treatmentDto.getDiagnosis(), treatmentDto.getDrugTreatment().getName(), treatmentDto.getDrugTreatment().getDosage());		
			}
			else if (treatmentDto.getRadiology() != null) {
				List<RadDate> radDates = new ArrayList<>();
				List<RadDateType> radDateTypes = treatmentDto.getRadiology().getDate();
				for (int i = 0; i < radDateTypes.size(); i++) {
					RadDate radDate = radDateFactory.createRadDate(radDateTypes.get(i).getDate());
					radDates.add(radDate);
				}
				treatment = treatmentFactory.createRadiology(treatmentDto.getDiagnosis(), radDates, radDateDAO);
			}
			else {
				treatment = treatmentFactory.createSurgery(treatmentDto.getDiagnosis(), treatmentDto.getSurgery().getDate());
			}
			return provider.addTreatment(treatment, patient);
		} catch (ProviderExn e) {
			throw new ProviderNotFoundExn(e.toString());
		} catch (PatientExn  e) {
			throw new PatientNotFoundExn(e.toString());
		}
	}

	@Resource(name="SiteInfo")
	private String siteInformation;
	
	@Override
	public String siteInfo() {
		return siteInformation;
	}

}
