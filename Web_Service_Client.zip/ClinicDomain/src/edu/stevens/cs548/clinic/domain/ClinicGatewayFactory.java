package edu.stevens.cs548.clinic.domain;

import javax.persistence.EntityManager;

public class ClinicGatewayFactory {

	public static ClinicGateway createClinicGateway (EntityManager em) {
		return new ClinicGateway(em);
	}
	
}
