package edu.stevens.cs548.clinic.domain;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

public class ProviderDAO implements IProviderDAO {
	
	private EntityManager em;
	private TreatmentDAO treatmentDAO;

	@Override
	public Provider getProviderByNPI(long npi) throws ProviderExn {
		TypedQuery<Provider> query = 
				em.createNamedQuery("SearchProviderByNPI", Provider.class)
				.setParameter("npi", npi);
		List<Provider> provider = query.getResultList();
		if(provider.size() > 1){
			throw new ProviderExn("Duplicate Provider records: provider id = " + npi);
		}else if(provider.size() < 1){
			throw new ProviderExn("Provider not found: provider id = " + npi);
		}else {
			Provider pr = provider.get(0);
			pr.setTreatmentDAO(this.treatmentDAO);
			return pr;
		}
	}

	@Override
	public Provider getProvider(long id) throws ProviderExn {
		Provider pr = em.find(Provider.class, id);
		if(pr == null){
			throw new ProviderExn("Patient not found: primary key = " + id);
		} else {
			pr.setTreatmentDAO(this.treatmentDAO);
			return pr;
		}
	}
	
	public ProviderDAO(EntityManager em) {
		this.em = em;
		this.treatmentDAO = new TreatmentDAO(em);
	}

	@Override
	public void addProvider(Provider provider) throws ProviderExn {
		long npi = provider.getNpi();
		Query query = em.createNamedQuery("CountProviderByNPI").setParameter("npi", npi);
		Long numExisting = (Long) query.getSingleResult();
		if (numExisting < 1) {
			// add to database (and sync with database to generate primary key)
			// Don't forget to initialize the Provider aggregate with a treatment DAO
			em.persist(provider);
			provider.setTreatmentDAO(this.treatmentDAO);
			//throw new IllegalStateException("Unimplemented");
			
		} else {
			throw new ProviderExn("Insertion: Patient with patient NPI (" + npi + ") already exists.");
		}
	}

	@Override
	public void deleteProvider() throws ProviderExn {
		
		TypedQuery<Provider> query = em.createQuery("select pv from Provider pv", Provider.class);
		List<Provider> providers = query.getResultList();
		if (providers.size() < 1)
			throw new ProviderExn("No providers to delete.");
		else
			for(Provider prv : providers){
				em.remove(prv);
			}
		
	}

}
