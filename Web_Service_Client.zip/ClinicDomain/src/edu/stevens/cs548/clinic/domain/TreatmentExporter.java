package edu.stevens.cs548.clinic.domain;

import java.util.Date;
import java.util.List;

public class TreatmentExporter<T> implements ITreatmentExporter<T> {

	@SuppressWarnings("unchecked")
	@Override
	public T exportDrugTreatment(long tid, String diagnosis, String drug, float dosage) {
		DrugTreatment drugTreatment = new DrugTreatment();
		drugTreatment.setId(tid);
		drugTreatment.setDiagnosis(diagnosis);
		drugTreatment.setDrug(drug);
		drugTreatment.setDosage(dosage);
		return (T) drugTreatment;
	}

	@SuppressWarnings("unchecked")
	@Override
	public T exportRadiology(long tid, String diagnosis, List<RadDate> dates) {
		Radiology radiology = new Radiology();
		radiology.setId(tid);
		radiology.setDiagnosis(diagnosis);
		radiology.setDates(dates);
		return (T) radiology;
	}

	@SuppressWarnings("unchecked")
	@Override
	public T exportSurgery(long tid, String diagnosis, Date date) {
		Surgery surgery = new Surgery();
		surgery.setId(tid);
		surgery.setDiagnosis(diagnosis);
		surgery.setDate(date);
		return (T) surgery;
	}

}
