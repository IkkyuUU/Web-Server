package edu.stevens.cs548.clinic.test;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.logging.Logger;

import javax.annotation.PostConstruct;
import javax.ejb.LocalBean;
import javax.ejb.Singleton;
import javax.ejb.Startup;
import javax.inject.Inject;
import javax.persistence.EntityManager;
import edu.stevens.cs548.clinic.domain.ClinicGateway;
import edu.stevens.cs548.clinic.domain.IClinicGateway;
import edu.stevens.cs548.clinic.domain.IPatientDAO.PatientExn;
import edu.stevens.cs548.clinic.domain.IPatientFactory;
import edu.stevens.cs548.clinic.domain.IRadDateFactory;
import edu.stevens.cs548.clinic.domain.Patient;
import edu.stevens.cs548.clinic.domain.RadDate;
import edu.stevens.cs548.clinic.service.dto.PatientDto;
import edu.stevens.cs548.clinic.service.dto.ProviderDto;
import edu.stevens.cs548.clinic.service.dto.RadDateType;
import edu.stevens.cs548.clinic.service.dto.SpecializationType;
import edu.stevens.cs548.clinic.service.dto.TreatmentDto;
import edu.stevens.cs548.clinic.service.dto.util.PatientDtoFactory;
import edu.stevens.cs548.clinic.service.dto.util.ProviderDtoFactory;
import edu.stevens.cs548.clinic.service.dto.util.TreatmentDtoFactory;
import edu.stevens.cs548.clinic.service.ejb.ClinicDomain;
import edu.stevens.cs548.clinic.service.ejb.IPatientService.PatientNotFoundExn;
import edu.stevens.cs548.clinic.service.ejb.IPatientService.PatientServiceExn;
import edu.stevens.cs548.clinic.service.ejb.IPatientService.TreatmentNotFoundExn;
import edu.stevens.cs548.clinic.service.ejb.IPatientServiceLocal;
import edu.stevens.cs548.clinic.service.ejb.IProviderService.ProviderServiceExn;
import edu.stevens.cs548.clinic.service.ejb.IProviderServiceLocal;

/**
 * Session Bean implementation class TestBean
 */
@Singleton
@LocalBean
@Startup
public class InitBean {

	private static Logger logger = Logger.getLogger(InitBean.class.getCanonicalName());

	/**
	 * Default constructor.
	 */
	public InitBean() {
	}

	@Inject
	private IPatientServiceLocal patientService;
	@Inject
	private IProviderServiceLocal providerService;

	@Inject
	@ClinicDomain
	EntityManager em;

	@PostConstruct
	private void init() {
		/*
		 * Put your testing logic here. Use the logger to display testing output
		 * in the server logs.
		 */
		logger.info("Zhiqian Yu, 10397116, Testing: ");

		PatientDtoFactory patientDtoFactory = new PatientDtoFactory();
		ProviderDtoFactory providerDtoFactory = new ProviderDtoFactory();
		TreatmentDtoFactory treatmentDtoFactory = new TreatmentDtoFactory();

		IClinicGateway clinicGateway = new ClinicGateway(em);

		IPatientFactory patientFactory = clinicGateway.getPatientFactory();
		IRadDateFactory radDateFactory = clinicGateway.getRadDateFactory();
		SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
		Date d = new Date();

		/*
		 * Clear the database and populate with fresh data.
		 * 
		 * If we ensure that deletion of patients cascades deletes of
		 * treatments, then we only need to delete patients.
		 */
		try {
			providerService.deleteProvider();
			logger.info("Delete all providers and corresponding treatments from database.");
			patientService.deletePatient();
			logger.info("Delete all patients from database.");
		} catch (ProviderServiceExn e) {
			logger.info(e.toString());
		} catch (PatientServiceExn e) {
			logger.info(e.toString());
		}

		/*
		 * Add patient to the database
		 */
		try {
			long[] PIDs = { 1, 2, 3, 4 };
			String[] patientNames = { "Jerry", "Tom", "Marry", "Jhon" };
			String[] dobs = { "1990-01-29", "1991-01-29", "1997-10-14", "1985-12-07" };
			int[] ages = { 25, 24, 18, 30 };
			for (int i = 0; i < PIDs.length; i++) {

				logger.info("***************************************************");
				logger.info("          Add a new patient to the database      ");

				d = format.parse(dobs[i]);
				Patient pat = patientFactory.createPatient(PIDs[i], patientNames[i], d, ages[i]);
				PatientDto patientDto = patientDtoFactory.createPatientDto(pat, ages[i]);
				long pid = patientService.addPatient(patientDto);

				logger.info("Added \"" + patientDto.getName() + "\" with patient ID " + patientDto.getPatientId()
						+ ", Database ID " + pid);
				logger.info("***************************************************");
			}

		} catch (PatientServiceExn e) {
			logger.info("Failed to add patient record \n" + e.toString());
		} catch (ParseException e) {
			e.printStackTrace();
		} catch (PatientExn e) {
			logger.info("Failed to add patient record \n" + e.toString());
		}

		// Add provider to the database
		try {
			long[] NPIs = { 1, 2, 3, 3 };
			String[] providerNames = { "Montclair Radiology", "Bayer", "Hospital for Special Surgery",
					"Cancer Surgery" };
			String[] specs = { "RADIOLOGY", "surgery", "Oncology", "SURGERY" };

			for (int i = 0; i < NPIs.length; i++) {
				logger.info("***************************************************");
				logger.info("       Add a new provider to the database     ");
				ProviderDto providerDto = providerDtoFactory.createProviderDto(NPIs[i], providerNames[i],
						SpecializationType.valueOf(specs[i].toUpperCase()));
				long id = providerService.addProvider(providerDto);
				logger.info("Added \"" + providerDto.getName() + "\" with provider ID " + providerDto.getProviderId()
						+ ", Database ID " + id + " with Spec " + providerDto.getSpecialization());
				logger.info("***************************************************");
			}
		} catch (ProviderServiceExn e) {
			logger.info("Failed to add a provider \n" + e.toString());
		}
		
		/*
		 *  Add treatments
		 */
		try{
			logger.info("***************************************************");
			logger.info("       Add a new treatment to the database     ");
			Calendar calendar = Calendar.getInstance();			
			List<RadDate> rDates = new ArrayList<RadDate>();
			
			PatientDto pat = patientService.getPatientByPatId(1);
			PatientDto pat2 = patientService.getPatientByPatId(2);
			
			ProviderDto prv1 = providerService.getProviderByNpi(1);
			ProviderDto prv2 = providerService.getProviderByNpi(2);
			ProviderDto prv3 = providerService.getProviderByNpi(3);
			
			try {
				calendar.set(1990, 12, 07);
				RadDate rd = radDateFactory.createRadDate(calendar.getTime());
				rDates.add(rd);
								
				calendar.set(1998, 10, 17);
				rd = radDateFactory.createRadDate(calendar.getTime());
				rDates.add(rd);
				
				
				calendar.set(2000, 01, 02);
				TreatmentDto trmt1 = treatmentDtoFactory.createTreatmentDto("Cancer", "Aspirin", (float)5, pat, prv1);
				TreatmentDto trmt2 = treatmentDtoFactory.createTreatmentDto("Headache", "Painkiller", (float)1.5, pat2, prv1);
				TreatmentDto trmt3 = treatmentDtoFactory.createTreatmentDto("Bone Fracture", calendar.getTime(), pat, prv2);
				TreatmentDto trmt4 = treatmentDtoFactory.createTreatmentDto("Cancer", rDates, pat, prv3);

				try {
					long id1 = providerService.addTreatment(trmt1);
					logger.info("Add Treatment (DB Id: " + id1 + ") Successfully Done!");
					long id2 = providerService.addTreatment(trmt2);
					logger.info("Add Treatment (DB Id: " + id2 + ") Successfully Done!");
					long id3 = providerService.addTreatment(trmt3);
					logger.info("Add Treatment (DB Id: " + id3 + ") Successfully Done!");
					long id4 = providerService.addTreatment(trmt4);
					logger.info("Add Treatment (DB Id: " + id4 + ") Successfully Done!");
					logger.info("***************************************************");

				} catch (Exception e) {
					logger.info("——Failed to add the treatment for the patient——\n" + e.toString());
				}

			} catch (Exception e) {
				logger.info("——Failed to create the treatment——\n" + e.toString());
			}
		} catch (PatientServiceExn e) {
			logger.info("Couldn't find this patient." + e.toString());
		} catch (ProviderServiceExn e) {
			logger.info("Couldn't find this provider." + e.toString());
		}
		
		/*
		 * retrieve patient by id and pid
		 */
		try {
			logger.info("***************************************************");
			logger.info("       Get patient by ID and PID     ");
			PatientDto p = patientService.getPatient(1);
			logger.info("Name: " + p.getName() + " with patient id " + p.getPatientId() + " date "
					+ "of birth " + p.getDob() );
			p = patientService.getPatient(2);
			logger.info("Name: " + p.getName() + " with patient id " + p.getPatientId() + " date "
					+ "of birth " + p.getDob() );
			p = patientService.getPatientByPatId(3);
			logger.info("Name: " + p.getName() + " with patient id " + p.getPatientId() + " date "
					+ "of birth " + p.getDob() );
			p = patientService.getPatientByPatId(8);
			logger.info("Name: " + p.getName() + " with patient id " + p.getPatientId() + " date "
					+ "of birth " + p.getDob() );
			logger.info("***************************************************");
		}catch (PatientServiceExn e) {
			logger.info("Fail to find patient : " + e.toString());
		}
		logger.info("***************************************************");
		
		
		/*
		 *  get provider by id and npi
		 */
		try {
			logger.info("***************************************************");
			logger.info("       Get provider by ID and PID     ");
			ProviderDto pr = providerService.getProviderByNpi(2);
			logger.info("Name : " + pr.getName() + " with NPI " + pr.getProviderId() + " with Spec " + pr.getSpecialization());
			pr = providerService.getProviderByNpi(1);
			logger.info("Name : " + pr.getName() + " with NPI " + pr.getProviderId() + " with Spec " + pr.getSpecialization());
		    pr = providerService.getProvider(5);
			logger.info("Name : " + pr.getName() + " with NPI " + pr.getId() + " with Spec " + pr.getSpecialization());
			pr = providerService.getProvider(10);
			logger.info("Name : " + pr.getName() + " with NPI " + pr.getProviderId() + " with Spec " + pr.getSpecialization());
			logger.info("***************************************************");
		}catch (ProviderServiceExn e) {
			logger.info("Fail to find patient : " + e.toString());
		}
		logger.info("***************************************************");
		
		
		/*
		 *  Retrieve treatment by patient
		 */
		try {
			logger.info("***************************************************");
			logger.info("       Get treatment by patient     ");

			TreatmentDto treatmentDto = patientService.getTreatment(1, 7);

			logger.info("Information of treatment with TreatmentID " + 7 + " for patient with PatientID " + 1 + " :");
			logger.info("Provider key: " + treatmentDto.getProvider());
			logger.info("Diagnosis: " + treatmentDto.getDiagnosis());
			if (treatmentDto.getDrugTreatment() != null) {
				logger.info("DrugTreatment: ");
				logger.info("Drug Name: " + treatmentDto.getDrugTreatment().getName());
				logger.info("Dosage: " + treatmentDto.getDrugTreatment().getDosage());
			} else if (treatmentDto.getSurgery() != null) {
				logger.info("Surgery:");
				logger.info("Surgery Date: " + format.format(treatmentDto.getSurgery().getDate()));
			} else {
				logger.info("Radiology:");
				logger.info("Dates: ");
				for (RadDateType rd : treatmentDto.getRadiology().getDate()) {
					logger.info(format.format(rd.getDate()));
				}
			}
		} catch (PatientNotFoundExn e) {
			logger.info(e.toString());
		} catch (TreatmentNotFoundExn e) {
			logger.info(e.toString());
		} catch (PatientServiceExn e) {
			logger.info(e.toString());
		}	
		
	}

}
